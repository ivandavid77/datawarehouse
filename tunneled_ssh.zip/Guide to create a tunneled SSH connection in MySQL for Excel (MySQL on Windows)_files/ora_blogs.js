var ora_local="ora_code_blogs.js";var ora_global="ora_code.js";var ora_path="/main/resource/resources/";
document.write("<script type='text/javascript' src='"+ora_path+ora_local+"'><\/script>");
document.write("<script type='text/javascript' src='"+ora_path+ora_global+"'><\/script>");
